import test from "node:test";
import assert from "node:assert/strict";
import { mergeSeedTokens } from "./index-store.js";

test("seed merge keeps discovery rows and adds Pons launches that were missing", () => {
  const discovery = [
    { chainId: "solana", baseToken: { address: "Mint111" } },
    { chainId: "robinhood", baseToken: { address: "0xaaa" }, launchPlatform: "Pons V2" },
  ];
  const pons = [
    { chainId: "robinhood", baseToken: { address: "0xAAA" }, launchPlatform: "Pons V2" },
    { chainId: "robinhood", baseToken: { address: "0xbbb" }, launchPlatform: "Pons V2" },
    { chainId: "robinhood", baseToken: {} },
  ];
  const merged = mergeSeedTokens(discovery, pons);
  assert.equal(merged.added, 1);
  assert.equal(merged.tokens.length, 3);
  assert.equal(merged.tokens[1].baseToken.address, "0xaaa");
  assert.equal(merged.tokens[2].baseToken.address, "0xbbb");
});
