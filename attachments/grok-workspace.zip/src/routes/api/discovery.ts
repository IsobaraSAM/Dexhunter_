import { createFileRoute } from "@tanstack/react-router";
import { discoveryEngine } from "../../../indexer/discovery-engine";
import { ensureDexHunterEngines } from "../../../indexer/engines-boot";
import { projectBrowseToken } from "../../../indexer/browse-shape";
import { DiscoveryQueryError, parseDiscoveryParams, queryIndex } from "../../../indexer/index-query";
import { repairPonsIdentity } from "../../../indexer/pons-identity";
import { ponsIndexer } from "../../../indexer/pons-engine";
import { resolveAddress } from "../../../indexer/address-lookup";
import { searchMarkets } from "../../../indexer/direct-search";

export const Route = createFileRoute("/api/discovery")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        ensureDexHunterEngines();
        repairPonsIdentity(discoveryEngine, ponsIndexer);
        const url = new URL(request.url);
        const direct = (url.searchParams.get("address") || "").trim();
        const textQuery = (url.searchParams.get("q") || "").trim();
        // List pages wait on a warm snapshot. A contract or name search should
        // not sit behind that — it asks the venue APIs itself.
        if (!direct && !textQuery) {
          await Promise.race([
            discoveryEngine.ensureLiveSnapshot(),
            new Promise((resolve) => setTimeout(resolve, 2500)),
          ]);
        }
        try {
          if (textQuery) {
            const tokens = await searchMarkets(textQuery);
            const shape = url.searchParams.get("shape");
            const rows = shape === "browse" ? tokens.map(projectBrowseToken) : tokens;
            return Response.json({
              success: true,
              total: rows.length,
              tokens: rows,
            });
          }
          if (direct) {
            const chain = url.searchParams.get("chain") || "all";
            const indexOnly = url.searchParams.get("indexOnly") === "1";
            const looked = await resolveAddress(Array.from(discoveryEngine.indexedTokens.values()), direct, chain, { indexOnly });
            if (looked.source === "chain") {
              for (const token of looked.tokens) discoveryEngine.ingestToken(token);
            }
            const shape = url.searchParams.get("shape");
            const rows = shape === "browse" ? looked.tokens.map(projectBrowseToken) : looked.tokens;
            return Response.json({
              success: true,
              lookedUp: true,
              total: rows.length,
              message: looked.message,
              ambiguous: Boolean(looked.ambiguous),
              chain: chain || "all",
              tokens: rows,
            });
          }
          const parsed = parseDiscoveryParams(url.searchParams);
          const tokens = Array.from(discoveryEngine.indexedTokens.values()) as Array<{ chainId?: string }>;
          const page = queryIndex(tokens, parsed);
          const shape = url.searchParams.get("shape");
          const rows = shape === "browse" ? page.tokens.map(projectBrowseToken) : page.tokens;
          return Response.json({
            success: true,
            total: page.total,
            nextCursor: page.nextCursor,
            limit: parsed.limit,
            age: parsed.age,
            chain: parsed.chain || "all",
            mode: parsed.mode,
            tokens: rows,
          });
        } catch (err) {
          if (err instanceof DiscoveryQueryError || (err as { name?: string })?.name === "DiscoveryQueryError") {
            return Response.json({ success: false, error: (err as Error).message }, { status: 400 });
          }
          throw err;
        }
      },
    },
  },
});
